"""
This module provides a simple demo script
"""


print("Hello world!")
